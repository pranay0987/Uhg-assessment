package com.example.demo;


import javax.persistence.*;

@Entity
public class Palindrome {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String palindromestring;
	
	public Palindrome() {
		super();
	}
	public Palindrome(String substring) {
		// TODO Auto-generated constructor stub
		super();
		//int id2, 
		//this.id = id2;
		this.palindromestring = substring;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPalindromeString() {
		return palindromestring;
	}
	public void setPalindromeString(String palindrome) {
		this.palindromestring = palindrome;
	}
	
	

}
