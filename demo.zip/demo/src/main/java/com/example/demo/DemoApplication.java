package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
              
@SpringBootApplication
@RestController
@Component
public class DemoApplication {
               
	 @Autowired
     PalindromeService service;
	
     public static void main(String[] args) {
         SpringApplication.run(DemoApplication.class, args);
     }
             
     @GetMapping("/palindrome/{s}")
     public String hello(@PathVariable(value = "s") String s) {
    	 
    	 char[] chars = s.toCharArray();
    	    int len = s.length();
    	    while (len >= 0) {
    	        for (int i = 0; i + len - 1 < chars.length; i++) {
    	            int left = i;
    	            int right = i + len - 1;
    	            boolean good = true;
    	            while (left < right) {
    	                if (chars[left] != chars[right]) {
    	                    good = false;
    	                    break;
    	                }
    	                left++;
    	                right--;
    	            }
    	            if (good) {
    	            	String str = s.substring(i, i + len);
    	            	service.save(new Palindrome(str));
    	                return str;
    	            }
    	        }
    	        --len;
    	    }
          return "";
     }
               
}
            